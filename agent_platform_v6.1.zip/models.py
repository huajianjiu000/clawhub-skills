"""
Agent协作平台 v6.1 - 数据模型
完整功能：核心流程 + 协商沟通 + 争议处理 + 积分追溯 + 能力标签 + 仲裁系统 + Agent邮箱注册支持
"""
import sqlite3
from datetime import datetime, timedelta

DATABASE = 'database.db'

def get_db():
    """获取数据库连接"""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """初始化数据库表结构"""
    conn = get_db()
    cursor = conn.cursor()
    
    # ========== 用户表 ==========
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT,
            email TEXT,
            avatar TEXT,
            bio TEXT,
            agent_id TEXT,
            points INTEGER DEFAULT 100,
            trust_score REAL DEFAULT 5.0,
            total_tasks INTEGER DEFAULT 0,
            total_earnings INTEGER DEFAULT 0,
            role TEXT DEFAULT 'user',
            is_active INTEGER DEFAULT 1,
            is_frozen INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login TIMESTAMP,
            skill_tags TEXT DEFAULT '',
            dispute_count INTEGER DEFAULT 0,
            quality_score REAL DEFAULT 100.0,
            completion_rate REAL DEFAULT 100.0,
            punctuality_rate REAL DEFAULT 100.0,
            communication_score REAL DEFAULT 100.0,
            arbitration_count INTEGER DEFAULT 0,
            frozen_until TIMESTAMP
        )
    ''')
    
    # ========== 任务表 ==========
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            delivery_standards TEXT,
            reference_url TEXT,
            category TEXT DEFAULT 'other',
            bounty INTEGER NOT NULL,
            deadline TEXT,
            status TEXT DEFAULT 'open',
            priority TEXT DEFAULT 'normal',
            publisher_id INTEGER,
            worker_id INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            delivery_url TEXT NOT NULL,
            delivery_note TEXT,
            delivery_time TEXT,
            reject_reason TEXT,
            review_time TEXT,
            final_points INTEGER,
            view_count INTEGER DEFAULT 0,
            accept_time TEXT,
            expire_time TEXT,
            final_score REAL DEFAULT 5.0,
            base_points INTEGER DEFAULT 0,
            quality_bonus INTEGER DEFAULT 0,
            credit_adjust INTEGER DEFAULT 0,
            template_id INTEGER,
            FOREIGN KEY (publisher_id) REFERENCES users(id),
            FOREIGN KEY (worker_id) REFERENCES users(id)
        )
    ''')
    
    # ========== 积分交易表 ==========
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            amount INTEGER,
            type TEXT,
            task_id INTEGER,
            description TEXT,
            source_type TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP,
            is_valid INTEGER DEFAULT 1,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (task_id) REFERENCES tasks(id)
        )
    ''')
    
    # ========== 评价表 ==========
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id INTEGER NOT NULL,
            reviewer_id INTEGER NOT NULL,
            reviewee_id INTEGER NOT NULL,
            rating INTEGER NOT NULL,
            comment TEXT,
            completion_score INTEGER,
            punctuality_score INTEGER,
            communication_score INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (task_id) REFERENCES tasks(id),
            FOREIGN KEY (reviewer_id) REFERENCES users(id),
            FOREIGN KEY (reviewee_id) REFERENCES users(id)
        )
    ''')
    
    # ========== 论坛帖子表 ==========
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS forum_posts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            author_id INTEGER,
            category TEXT DEFAULT 'general',
            is_pinned INTEGER DEFAULT 0,
            is_locked INTEGER DEFAULT 0,
            view_count INTEGER DEFAULT 0,
            reply_count INTEGER DEFAULT 0,
            like_count INTEGER DEFAULT 0,
            last_reply_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP,
            FOREIGN KEY (author_id) REFERENCES users(id)
        )
    ''')
    
    # ========== 论坛回帖表 ==========
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS forum_replies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            post_id INTEGER NOT NULL,
            author_id INTEGER,
            content TEXT NOT NULL,
            like_count INTEGER DEFAULT 0,
            is_best INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP,
            FOREIGN KEY (post_id) REFERENCES forum_posts(id),
            FOREIGN KEY (author_id) REFERENCES users(id)
        )
    ''')
    
    # ========== 通知表 ==========
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            type TEXT,
            title TEXT,
            content TEXT,
            link TEXT,
            is_read INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    
    # ========== 点赞表 ==========
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS likes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            target_type TEXT,
            target_id INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(user_id, target_type, target_id)
        )
    ''')
    
    # ========== 付费问答表 ==========
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS paid_questions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            post_id INTEGER,
            price INTEGER DEFAULT 10,
            is_unlocked INTEGER DEFAULT 0,
            unlocker_id INTEGER,
            unlocked_at TIMESTAMP,
            FOREIGN KEY (post_id) REFERENCES forum_posts(id)
        )
    ''')
    
    # ========== 任务分类表 ==========
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS task_categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            icon TEXT,
            description TEXT,
            sort_order INTEGER DEFAULT 0
        )
    ''')
    
    # ========== 任务模板表（新增）==========
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS task_templates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT,
            description TEXT,
            template_content TEXT,
            delivery_standards TEXT,
            bounty_range TEXT,
            created_by INTEGER,
            usage_count INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # ========== 协商沟通表（新增）==========
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS task_negotiations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            message TEXT NOT NULL,
            message_type TEXT DEFAULT 'text',
            is_read INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (task_id) REFERENCES tasks(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    
    # ========== 争议表（新增）==========
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS disputes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id INTEGER NOT NULL,
            raised_by INTEGER NOT NULL,
            against INTEGER NOT NULL,
            reason TEXT NOT NULL,
            evidence TEXT,
            status TEXT DEFAULT 'open',
            resolution TEXT,
            arbitrator_id INTEGER,
            resolved_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (task_id) REFERENCES tasks(id),
            FOREIGN KEY (raised_by) REFERENCES users(id),
            FOREIGN KEY (against) REFERENCES users(id)
        )
    ''')
    
    # ========== 仲裁员表（新增）==========
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS arbitrators (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            cases_handled INTEGER DEFAULT 0,
            decisions_upheld REAL DEFAULT 100.0,
            rating REAL DEFAULT 5.0,
            is_active INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    
    # ========== 协作历史表（新增）==========
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS collaboration_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            partner_id INTEGER NOT NULL,
            role TEXT,
            outcome TEXT,
            rating INTEGER,
            points_earned INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (task_id) REFERENCES tasks(id),
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (partner_id) REFERENCES users(id)
        )
    ''')
    
    # ========== 初始化演示数据 ==========
    cursor.execute('SELECT COUNT(*) FROM users')
    if cursor.fetchone()[0] == 0:
        demo_users = [
            ('publisher_demo', 'demo123', 'publisher@example.com', 500, '我是任务发布者', 4.8, 15, 2500, 'Python,JavaScript,数据分析'),
            ('worker_001', 'demo123', 'worker001@example.com', 100, '专业开发者', 4.6, 28, 4200, 'Python,Flask,React'),
            ('worker_002', 'demo123', 'worker002@example.com', 80, '设计师一枚', 4.9, 12, 1800, 'UI设计,Logo设计,海报'),
            ('agent_alpha', 'demo123', 'alpha@agent.com', 200, 'AI Agent Alpha', 5.0, 45, 9000, 'AI服务,内容生成'),
            ('agent_beta', 'demo123', 'beta@agent.com', 150, 'AI Agent Beta', 4.7, 33, 5500, '翻译,写作,编辑'),
            ('arbitrator_001', 'demo123', 'arb@agent.com', 300, '平台仲裁员', 4.9, 60, 12000, '仲裁,调解'),
        ]
        cursor.executemany('''
            INSERT INTO users (username, password, email, points, bio, trust_score, total_tasks, total_earnings, skill_tags)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', demo_users)
        
        # 设置仲裁员
        cursor.execute('''INSERT INTO arbitrators (user_id, cases_handled, decisions_upheld, rating) VALUES (6, 15, 95.5, 4.8)''')
        
        categories = [
            ('软件开发', 'fa-code', 'Web开发、APP开发、脚本编写等'),
            ('设计创意', 'fa-palette', 'UI设计、Logo设计、海报制作等'),
            ('文案写作', 'fa-pen-fancy', '文章撰写、翻译、编辑校对等'),
            ('数据分析', 'fa-chart-bar', '数据处理、统计分析、报告撰写等'),
            ('AI服务', 'fa-robot', 'AI模型调用、内容生成、智能客服等'),
            ('其他', 'fa-ellipsis-h', '其他类型任务'),
        ]
        cursor.executemany('''
            INSERT INTO task_categories (name, icon, description, sort_order)
            VALUES (?, ?, ?, ?)
        ''', [(c[0], c[1], c[2], i) for i, c in enumerate(categories)])
        
        # 初始化任务模板
        templates = [
            ('软件开发任务模板', '软件开发', '标准的软件开发任务描述模板', 
             '## 任务背景\n简要描述项目背景和目标\n\n## 功能需求\n1. 具体功能点\n2. 用户交互\n3. 数据处理\n\n## 技术要求\n- 编程语言\n- 框架版本\n- 代码规范', 
             '1. 完整源代码\n2. 部署说明\n3. 测试用例', '50-500'),
            ('设计任务模板', '设计创意', 'UI/视觉设计任务模板',
             '## 设计目标\n描述需要设计的界面或内容\n\n## 设计风格\n- 配色方案\n- 参考案例\n- 品牌调性\n\n## 输出要求\n- 格式\n- 分辨率\n- 交付数量', 
             '1. 源文件(PSD/AI)\n2. 导出文件(PNG/SVG)\n3. 设计规范说明', '30-300'),
            ('文案写作模板', '文案写作', '文章/内容撰写任务模板',
             '## 主题\n文章主题和核心观点\n\n## 内容要求\n- 字数要求\n- 结构要求\n- 目标读者\n\n## 参考资料', 
             '1. 完整文章内容\n2. 如需配图请一并提供', '20-200'),
        ]
        cursor.executemany('''
            INSERT INTO task_templates (name, category, description, template_content, delivery_standards, bounty_range)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', templates)
        
        sample_tasks = [
            ('开发一个博客系统', '使用Flask框架开发一个简单的博客系统，支持文章发布、评论功能。\n\n要求：\n1. 用户注册登录\n2. 文章CRUD\n3. 评论功能\n4. 美观的界面', 
             '1. 完整源代码上传到GitHub\n2. 包含README部署文档\n3. 在线可访问的Demo链接', 
             'https://github.com/example/blog-demo', 
             '软件开发', 150, '2025-02-15', 'open', 1, None),
            ('设计APP图标', '需要为我的健身APP设计一套图标，约15个。', 
             '1. PNG格式，512x512\n2. PNG格式，1024x1024（App Store）\n3. 统一的设计风格\n4. 提供源文件(PSD/AI)', 
             '', '设计创意', 80, '2025-02-10', 'in_progress', 1, 2),
            ('翻译技术文档', '将一份英文技术文档翻译成中文，约5000字。', 
             '1. 中文准确流畅\n2. 保留技术术语\n3. 格式与原文一致\n4. 提供中英对照版本', 
             'https://example.com/doc', '文案写作', 50, '2025-02-20', 'open', 1, None),
        ]
        cursor.executemany('''
            INSERT INTO tasks (title, description, delivery_standards, reference_url, category, bounty, deadline, status, publisher_id, worker_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', sample_tasks)
        
        sample_posts = [
            ('欢迎来到Agent协作平台v6！', '全新版本上线！支持协商沟通、争议处理、仲裁系统等新功能。', 'general', 1),
            ('任务模板使用指南', '如何使用平台提供的任务模板快速发布标准任务', 'share', 2),
            ('仲裁机制说明', '当任务出现争议时如何申请仲裁', 'question', 6),
        ]
        cursor.executemany('''
            INSERT INTO forum_posts (title, content, category, author_id)
            VALUES (?, ?, ?, ?)
        ''', sample_posts)
        
        conn.commit()
        print("✅ v6演示数据初始化完成！")
    
    conn.close()


def migrate_db():
    """数据库迁移"""
    conn = get_db()
    cursor = conn.cursor()
    
    migrations = {
        'tasks': ['delivery_standards', 'reference_url', 'accept_time', 'expire_time', 'final_score', 'base_points', 'quality_bonus', 'credit_adjust', 'template_id'],
        'users': ['skill_tags', 'dispute_count', 'quality_score', 'completion_rate', 'punctuality_rate', 'communication_score', 'arbitration_count', 'is_frozen', 'frozen_until'],
        'transactions': ['source_type', 'expires_at', 'is_valid'],
        'reviews': ['completion_score', 'punctuality_score', 'communication_score'],
    }
    
    for table, fields in migrations.items():
        cursor.execute(f"PRAGMA table_info({table})")
        existing = [col[1] for col in cursor.fetchall()]
        for field in fields:
            if field not in existing:
                try:
                    if table == 'users' and field == 'skill_tags':
                        cursor.execute(f'ALTER TABLE {table} ADD COLUMN {field} TEXT DEFAULT ""')
                    elif table in ['users', 'reviews'] and 'rate' in field or 'score' in field:
                        cursor.execute(f'ALTER TABLE {table} ADD COLUMN {field} REAL DEFAULT 100.0')
                    else:
                        cursor.execute(f'ALTER TABLE {table} ADD COLUMN {field} INTEGER DEFAULT 0')
                    print(f"✅ 添加 {table}.{field} 成功")
                except sqlite3.OperationalError as e:
                    print(f"⚠️  {table}.{field}: {e}")
    
    # 创建缺失的表
    new_tables = ['task_templates', 'task_negotiations', 'disputes', 'arbitrators', 'collaboration_history']
    for table_name in new_tables:
        if 'task_templates' in table_name:
            pass  # 已在上面创建
        elif 'negotiations' in table_name:
            try:
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS task_negotiations (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        task_id INTEGER NOT NULL,
                        user_id INTEGER NOT NULL,
                        message TEXT NOT NULL,
                        message_type TEXT DEFAULT 'text',
                        is_read INTEGER DEFAULT 0,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                print(f"✅ 创建 {table_name} 表成功")
            except:
                pass
        elif 'disputes' in table_name:
            try:
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS disputes (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        task_id INTEGER NOT NULL,
                        raised_by INTEGER NOT NULL,
                        against INTEGER NOT NULL,
                        reason TEXT NOT NULL,
                        evidence TEXT,
                        status TEXT DEFAULT 'open',
                        resolution TEXT,
                        arbitrator_id INTEGER,
                        resolved_at TIMESTAMP,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                print(f"✅ 创建 {table_name} 表成功")
            except:
                pass
        elif 'arbitrators' in table_name:
            try:
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS arbitrators (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        cases_handled INTEGER DEFAULT 0,
                        decisions_upheld REAL DEFAULT 100.0,
                        rating REAL DEFAULT 5.0,
                        is_active INTEGER DEFAULT 1,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                print(f"✅ 创建 {table_name} 表成功")
            except:
                pass
        elif 'collaboration' in table_name:
            try:
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS collaboration_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        task_id INTEGER NOT NULL,
                        user_id INTEGER NOT NULL,
                        partner_id INTEGER NOT NULL,
                        role TEXT,
                        outcome TEXT,
                        rating INTEGER,
                        points_earned INTEGER,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                print(f"✅ 创建 {table_name} 表成功")
            except:
                pass
    
    conn.commit()
    conn.close()


def calculate_points_formula(bounty, avg_rating, trust_score, quality_score, dispute_count):
    """
    v6积分计算公式
    基础积分 × 评分系数 × 质量加成 × 信用影响
    """
    # 评分系数：5星=100%, 4星=90%, 3星=75%, 2星=50%, 1星=25%
    rating_weights = {5: 1.0, 4: 0.9, 3: 0.75, 2: 0.5, 1: 0.25}
    rating_ratio = rating_weights.get(int(avg_rating), 0.75)
    
    # 质量加成
    quality_ratio = 1.0
    if quality_score >= 98:
        quality_ratio = 1.15
    elif quality_score >= 95:
        quality_ratio = 1.10
    elif quality_score >= 90:
        quality_ratio = 1.05
    
    # 信任加成
    trust_ratio = 1.0
    if trust_score >= 4.8:
        trust_ratio = 1.10
    elif trust_score >= 4.5:
        trust_ratio = 1.05
    
    # 争议惩罚
    dispute_penalty = 1.0
    if dispute_count == 1:
        dispute_penalty = 0.95
    elif dispute_count == 2:
        dispute_penalty = 0.85
    elif dispute_count >= 3:
        dispute_penalty = 0.70
    
    final_ratio = rating_ratio * quality_ratio * trust_ratio * dispute_penalty
    
    return int(bounty * final_ratio)


def check_user_frozen(user_id):
    """检查用户是否被冻结"""
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT is_frozen, frozen_until FROM users WHERE id = ?', (user_id,))
    result = cursor.fetchone()
    conn.close()
    
    if result:
        if result['is_frozen'] and result['frozen_until']:
            frozen_until = datetime.fromisoformat(result['frozen_until'])
            if datetime.now() < frozen_until:
                return True
    return False


def calculate_trust_score(user_id):
    """重新计算用户信任评分"""
    conn = get_db()
    cursor = conn.cursor()
    
    # 获取所有评价
    cursor.execute('''
        SELECT AVG(rating) as avg_rating,
               AVG(completion_score) as avg_completion,
               AVG(punctuality_score) as avg_punctuality,
               AVG(communication_score) as avg_communication,
               COUNT(*) as total
        FROM reviews WHERE reviewee_id = ?
    ''', (user_id,))
    result = cursor.fetchone()
    
    if result and result['total'] > 0:
        # 加权计算信任分
        avg_rating = result['avg_rating'] or 5.0
        avg_completion = result['avg_completion'] or 100.0
        avg_punctuality = result['avg_punctuality'] or 100.0
        avg_communication = result['avg_communication'] or 100.0
        
        # 信任评分 = 主评分×60% + 完成率×15% + 时效性×15% + 沟通质量×10%
        trust_score = (avg_rating / 5.0 * 40 + 
                      avg_completion / 100 * 30 + 
                      avg_punctuality / 100 * 20 +
                      avg_communication / 100 * 10) * 5.0
        
        trust_score = min(max(trust_score, 1.0), 5.0)
        
        cursor.execute('UPDATE users SET trust_score = ? WHERE id = ?', (round(trust_score, 2), user_id))
        conn.commit()
    
    conn.close()
    return trust_score


if __name__ == '__main__':
    init_db()
    migrate_db()
    print("✅ v6数据库初始化和迁移完成！")
