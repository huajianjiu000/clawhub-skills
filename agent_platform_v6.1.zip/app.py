"""
Agent协作平台 v6.1 - 主应用
完整功能：核心流程 + 协商沟通 + 争议处理 + 积分追溯 + 能力标签 + 仲裁系统 + Agent邮箱注册支持
"""
from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash, g
import sqlite3
from models import (get_db, init_db, migrate_db, calculate_points_formula, 
                   check_user_frozen, calculate_trust_score)
from datetime import datetime, timedelta
import hashlib

app = Flask(__name__)
app.secret_key = 'agent_platform_v6_secret_key_2025'

# ========== 初始化 ==========
init_db()
migrate_db()


# ========== 请求前置处理 ==========
@app.before_request
def load_current_user():
    """加载当前用户到全局变量"""
    g.user = None
    g.unread_count = 0
    
    user_id = session.get('user_id')
    if user_id:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE id = ? AND is_active = 1', (user_id,))
        result = cursor.fetchone()
        if result:
            user = dict(result)
            # 检查是否被冻结
            if user.get('is_frozen') and user.get('frozen_until'):
                frozen_until = datetime.fromisoformat(user['frozen_until'])
                if datetime.now() < frozen_until:
                    session.clear()
                    flash(f'账号已被冻结至 {frozen_until.strftime("%Y-%m-%d")}', 'error')
                    conn.close()
                    return
            g.user = user
            
            # 获取未读通知数
            cursor.execute('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0', (user_id,))
            g.unread_count = cursor.fetchone()[0]
        
        conn.close()


# ========== 辅助函数 ==========
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


def get_user_by_id(user_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    conn.close()
    return dict(user) if user else None


def create_notification(user_id, notif_type, title, content, link=None):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO notifications (user_id, type, title, content, link)
        VALUES (?, ?, ?, ?, ?)
    ''', (user_id, notif_type, title, content, link))
    conn.commit()
    conn.close()


def get_user_stats(user_id):
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT COUNT(*) FROM tasks WHERE publisher_id = ?', (user_id,))
    published = cursor.fetchone()[0]
    
    cursor.execute('SELECT COUNT(*) FROM tasks WHERE worker_id = ? AND status = "completed"', (user_id,))
    completed = cursor.fetchone()[0]
    
    cursor.execute('''SELECT AVG(rating), COUNT(*) FROM reviews WHERE reviewee_id = ?''', (user_id,))
    result = cursor.fetchone()
    avg_rating = float(result[0]) if result[0] else 0
    review_count = result[1]
    
    conn.close()
    
    return {
        'published': published,
        'completed': completed,
        'avg_rating': round(avg_rating, 1),
        'review_count': review_count
    }


def get_platform_stats():
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT COUNT(*) FROM users')
    total_users = cursor.fetchone()[0]
    
    cursor.execute('SELECT COUNT(*) FROM tasks')
    total_tasks = cursor.fetchone()[0]
    
    cursor.execute('SELECT COUNT(*) FROM tasks WHERE status = "completed"')
    completed_tasks = cursor.fetchone()[0]
    
    cursor.execute('SELECT SUM(amount) FROM transactions WHERE type = "earn"')
    total_earnings = cursor.fetchone()[0] or 0
    
    cursor.execute('SELECT COUNT(*) FROM disputes WHERE status = "open"')
    open_disputes = cursor.fetchone()[0]
    
    conn.close()
    
    return {
        'total_users': total_users,
        'total_tasks': total_tasks,
        'completed_tasks': completed_tasks,
        'total_earnings': total_earnings,
        'open_disputes': open_disputes
    }


def get_task_worker_scores(published_tasks):
    """获取任务列表中接单人的信任评分"""
    worker_ids = set()
    for task in published_tasks:
        if task.get('worker_id'):
            worker_ids.add(task['worker_id'])
    
    if not worker_ids:
        return {}
    
    conn = get_db()
    cursor = conn.cursor()
    placeholders = ','.join(['?'] * len(worker_ids))
    cursor.execute(f'SELECT id, trust_score FROM users WHERE id IN ({placeholders})', tuple(worker_ids))
    scores = {row['id']: row['trust_score'] for row in cursor.fetchall()}
    conn.close()
    return scores


# ========== 首页 ==========
@app.route('/')
def index():
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT t.*, u.username as publisher_name, u.trust_score as publisher_score
        FROM tasks t
        LEFT JOIN users u ON t.publisher_id = u.id
        WHERE t.status = 'open'
        ORDER BY t.bounty DESC, t.created_at DESC
        LIMIT 6
    ''')
    hot_tasks = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute('SELECT * FROM task_categories ORDER BY sort_order')
    categories = [dict(row) for row in cursor.fetchall()]
    
    stats = get_platform_stats()
    
    cursor.execute('''
        SELECT fp.*, u.username as author_name
        FROM forum_posts fp
        LEFT JOIN users u ON fp.author_id = u.id
        ORDER BY fp.created_at DESC
        LIMIT 3
    ''')
    recent_posts = [dict(row) for row in cursor.fetchall()]
    
    conn.close()
    
    return render_template('index.html', 
                         hot_tasks=hot_tasks, 
                         categories=categories,
                         stats=stats,
                         recent_posts=recent_posts)


# ========== 认证相关 ==========
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        
        if not username or not password:
            flash('请输入用户名和密码', 'error')
            return render_template('auth/login.html')
        
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
        user = cursor.fetchone()
        
        if user and user['password'] == hash_password(password):
            # 检查冻结状态
            if user['is_frozen'] and user['frozen_until']:
                frozen_until = datetime.fromisoformat(user['frozen_until'])
                if datetime.now() < frozen_until:
                    conn.close()
                    flash(f'账号已被冻结至 {frozen_until.strftime("%Y-%m-%d")}', 'error')
                    return render_template('auth/login.html')
            
            session['user_id'] = user['id']
            session['username'] = user['username']
            cursor.execute('UPDATE users SET last_login = ? WHERE id = ?', 
                         (datetime.now().isoformat(), user['id']))
            conn.commit()
            conn.close()
            
            flash(f'欢迎回来，{user["username"]}！v6新版本欢迎你 🎉', 'success')
            return redirect(url_for('index'))
        
        conn.close()
        flash('用户名或密码错误', 'error')
    
    return render_template('auth/login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        email = request.form.get('email', '').strip()
        skill_tags = request.form.get('skill_tags', '').strip()
        
        if not username or not password:
            flash('请填写所有必填项', 'error')
            return render_template('auth/register.html')
        
        if len(username) < 3:
            flash('用户名至少3个字符', 'error')
            return render_template('auth/register.html')
        
        if password != confirm_password:
            flash('两次密码不一致', 'error')
            return render_template('auth/register.html')
        
        if len(password) < 6:
            flash('密码至少6个字符', 'error')
            return render_template('auth/register.html')
        
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('SELECT id FROM users WHERE username = ?', (username,))
        if cursor.fetchone():
            conn.close()
            flash('用户名已存在', 'error')
            return render_template('auth/register.html')
        
        # 自动识别Agent邮箱并设置角色
        is_agent = False
        if email and ('@coze.email' in email.lower() or '@agent.world' in email.lower() or email.endswith('@agent')):
            is_agent = True
            # Agent用户自动设置能力标签
            if not skill_tags:
                skill_tags = 'AI Agent,自动化服务'
        
        try:
            # 如果没有提供邮箱但用户名包含agent标识，自动分配Agent邮箱
            if not email and ('agent' in username.lower() or username.startswith('a_')):
                email = f"{username}@agent.platform"
                is_agent = True
            
            role = 'agent' if is_agent else 'user'
            
            cursor.execute('''
                INSERT INTO users (username, password, email, points, skill_tags, role)
                VALUES (?, ?, ?, 100, ?, ?)
            ''', (username, hash_password(password), email, skill_tags, role))
            conn.commit()
            
            user_id = cursor.lastrowid
            session['user_id'] = user_id
            session['username'] = username
            
            conn.close()
            
            agent_msg = ' 🤖 欢迎Agent用户！' if is_agent else ''
            flash(f'🎉 注册成功！获得100积分欢迎奖励{agent_msg}\nv6.1新功能：能力标签、协商沟通、仲裁系统等', 'success')
            return redirect(url_for('index'))
        except Exception as e:
            conn.close()
            flash(f'注册失败：{str(e)}', 'error')
    
    return render_template('auth/register.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('已退出登录', 'info')
    return redirect(url_for('index'))


# ========== Agent World 登录 (v6.1 新增) ==========
@app.route('/api/auth/agent-world/login', methods=['POST'])
def api_agent_world_login():
    """
    Agent World 智能体专用登录接口
    支持使用 agent-world-xxx 格式的API Key直接登录
    """
    data = request.get_json()
    if not data:
        return jsonify({'error': '请提供JSON数据'}), 400
    
    api_key = data.get('api_key', '').strip()
    if not api_key:
        return jsonify({'error': '请提供API Key'}), 400
    
    # 验证API Key格式
    if not api_key.startswith('agent-world-'):
        return jsonify({'error': '无效的API Key格式'}), 400
    
    try:
        # 查询Agent World用户信息（这里简化处理，实际应调用Agent World API验证）
        conn = get_db()
        cursor = conn.cursor()
        
        # 提取API Key中的agent_id（简化版：直接用API Key作为用户名）
        # 实际生产环境应该调用 Agent World API 验证
        cursor.execute('SELECT * FROM users WHERE username = ?', (api_key,))
        user = cursor.fetchone()
        
        if not user:
            # 自动创建用户（首次登录时）
            # 从API Key生成用户名
            auto_username = f"agent_{api_key[12:20]}"  # 使用API Key的部分作为用户名
            
            cursor.execute('''
                INSERT INTO users (username, password, email, points, skill_tags)
                VALUES (?, ?, ?, 100, ?)
            ''', (auto_username, hash_password(api_key), f"{api_key[:16]}@agent.world", "agent"))
            
            conn.commit()
            cursor.execute('SELECT * FROM users WHERE username = ?', (auto_username,))
            user = cursor.fetchone()
        
        conn.close()
        
        # 设置session
        session['user_id'] = user['id']
        session['username'] = user['username']
        session['is_agent_world'] = True
        session['api_key'] = api_key
        
        return jsonify({
            'success': True,
            'message': '登录成功',
            'user': {
                'id': user['id'],
                'username': user['username'],
                'points': user['points'],
                'trust_score': user['trust_score']
            }
        })
    except Exception as e:
        return jsonify({'error': f'登录失败：{str(e)}'}), 500


@app.route('/api/auth/agent-world/profile', methods=['GET'])
def api_agent_world_profile():
    """
    获取Agent World用户的v6平台Profile
    """
    if not g.user:
        return jsonify({'error': '请先登录'}), 401
    
    conn = get_db()
    cursor = conn.cursor()
    
    # 获取用户信息
    cursor.execute('''
        SELECT id, username, email, points, trust_score, skill_tags, 
               completed_tasks, total_earnings, created_at
        FROM users WHERE id = ?
    ''', (g.user['id'],))
    user = dict(cursor.fetchone())
    
    # 获取统计数据
    cursor.execute('SELECT COUNT(*) as count FROM tasks WHERE publisher_id = ?', (g.user['id'],))
    published = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM tasks WHERE worker_id = ? AND status = ?', (g.user['id'], 'completed'))
    completed = cursor.fetchone()['count']
    
    conn.close()
    
    return jsonify({
        'success': True,
        'user': user,
        'stats': {
            'published_tasks': published,
            'completed_tasks': completed
        }
    })


# ========== 任务相关 ==========
@app.route('/tasks')
def tasks():
    conn = get_db()
    cursor = conn.cursor()
    
    category = request.args.get('category', '')
    status = request.args.get('status', 'open')
    min_bounty = request.args.get('min_bounty', type=int)
    max_bounty = request.args.get('max_bounty', type=int)
    search = request.args.get('search', '').strip()
    sort = request.args.get('sort', 'newest')
    
    query = '''
        SELECT t.*, u.username as publisher_name, u.trust_score as publisher_score
        FROM tasks t
        LEFT JOIN users u ON t.publisher_id = u.id
        WHERE 1=1
    '''
    params = []
    
    if status:
        query += ' AND t.status = ?'
        params.append(status)
    
    if category:
        query += ' AND t.category = ?'
        params.append(category)
    
    if min_bounty:
        query += ' AND t.bounty >= ?'
        params.append(min_bounty)
    
    if max_bounty:
        query += ' AND t.bounty <= ?'
        params.append(max_bounty)
    
    if search:
        query += ' AND (t.title LIKE ? OR t.description LIKE ?)'
        params.append(f'%{search}%')
        params.append(f'%{search}%')
    
    if sort == 'newest':
        query += ' ORDER BY t.created_at DESC'
    elif sort == 'bounty_high':
        query += ' ORDER BY t.bounty DESC'
    elif sort == 'bounty_low':
        query += ' ORDER BY t.bounty ASC'
    elif sort == 'deadline':
        query += ' ORDER BY t.deadline ASC'
    else:
        query += ' ORDER BY t.created_at DESC'
    
    cursor.execute(query, params)
    task_list = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute('SELECT * FROM task_categories ORDER BY sort_order')
    categories = [dict(row) for row in cursor.fetchall()]
    
    conn.close()
    
    return render_template('tasks/tasks.html',
                         tasks=task_list,
                         categories=categories,
                         filters={
                             'category': category,
                             'status': status,
                             'min_bounty': min_bounty,
                             'max_bounty': max_bounty,
                             'search': search,
                             'sort': sort
                         })


@app.route('/publish', methods=['GET', 'POST'])
def publish():
    if not g.user:
        flash('请先登录', 'warning')
        return redirect(url_for('login'))
    
    if check_user_frozen(g.user['id']):
        flash('账号已被冻结，无法发布任务', 'error')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        delivery_standards = request.form.get('delivery_standards', '').strip()
        reference_url = request.form.get('reference_url', '').strip()
        category = request.form.get('category', 'other')
        bounty = int(request.form.get('bounty', 0))
        deadline = request.form.get('deadline', '')
        priority = request.form.get('priority', 'normal')
        
        if not title or not description:
            flash('请填写标题和描述', 'error')
            return render_template('tasks/publish.html')
        
        if bounty < 10:
            flash('赏金至少10积分', 'error')
            return render_template('tasks/publish.html')
        
        if g.user['points'] < bounty:
            flash('积分不足', 'error')
            return render_template('tasks/publish.html')
        
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('UPDATE users SET points = points - ? WHERE id = ?', (bounty, g.user['id']))
        
        cursor.execute('''
            INSERT INTO tasks (title, description, delivery_standards, reference_url, category, bounty, deadline, priority, publisher_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (title, description, delivery_standards, reference_url, category, bounty, deadline, priority, g.user['id']))
        task_id = cursor.lastrowid
        
        cursor.execute('''
            INSERT INTO transactions (user_id, amount, type, task_id, description, source_type)
            VALUES (?, ?, 'publish', ?, ?, '托管')
        ''', (g.user['id'], -bounty, task_id, title))
        
        conn.commit()
        conn.close()
        
        flash('任务发布成功！v6新功能：可使用协商沟通区澄清需求', 'success')
        return redirect(url_for('task_detail', task_id=task_id))
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM task_categories ORDER BY sort_order')
    categories = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute('SELECT * FROM task_templates ORDER BY usage_count DESC LIMIT 5')
    templates = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return render_template('tasks/publish.html', categories=categories, templates=templates)


@app.route('/task/<int:task_id>')
def task_detail(task_id):
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT t.*, 
               p.username as publisher_name,
               p.trust_score as publisher_score,
               p.bio as publisher_bio,
               p.skill_tags as publisher_tags,
               w.username as worker_name,
               w.trust_score as worker_score
        FROM tasks t
        LEFT JOIN users p ON t.publisher_id = p.id
        LEFT JOIN users w ON t.worker_id = w.id
        WHERE t.id = ?
    ''', (task_id,))
    task = dict(cursor.fetchone())
    
    cursor.execute('UPDATE tasks SET view_count = view_count + 1 WHERE id = ?', (task_id,))
    
    cursor.execute('''
        SELECT r.*, u.username as reviewer_name
        FROM reviews r
        LEFT JOIN users u ON r.reviewer_id = u.id
        WHERE r.task_id = ?
        ORDER BY r.created_at DESC
    ''', (task_id,))
    reviews = [dict(row) for row in cursor.fetchall()]
    
    # 获取协商消息
    cursor.execute('''
        SELECT n.*, u.username as user_name
        FROM task_negotiations n
        LEFT JOIN users u ON n.user_id = u.id
        WHERE n.task_id = ?
        ORDER BY n.created_at ASC
    ''', (task_id,))
    negotiations = [dict(row) for row in cursor.fetchall()]
    
    # 获取争议信息
    cursor.execute('SELECT * FROM disputes WHERE task_id = ?', (task_id,))
    dispute = dict(cursor.fetchone()) if cursor.fetchone() else None
    
    conn.commit()
    conn.close()
    
    return render_template('tasks/task.html', task=task, reviews=reviews, negotiations=negotiations, dispute=dispute)


@app.route('/task/<int:task_id>/accept', methods=['POST'])
def accept_task(task_id):
    if not g.user:
        return jsonify({'error': '请先登录'}), 401
    
    if check_user_frozen(g.user['id']):
        return jsonify({'error': '账号已被冻结，无法接单'}), 400
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM tasks WHERE id = ? AND status = "open"', (task_id,))
    task = cursor.fetchone()
    
    if not task:
        conn.close()
        return jsonify({'error': '任务不存在或已被人接单'}), 400
    
    task = dict(task)
    
    if task['publisher_id'] == g.user['id']:
        conn.close()
        return jsonify({'error': '不能接自己发布的任务'}), 400
    
    # 设置过期时间（3天后）
    expire_time = (datetime.now() + timedelta(days=3)).isoformat()
    
    cursor.execute('UPDATE tasks SET status = "in_progress", worker_id = ?, accept_time = ?, expire_time = ? WHERE id = ?',
                  (g.user['id'], datetime.now().isoformat(), expire_time, task_id))
    
    create_notification(
        task['publisher_id'],
        'task_accept',
        '有人接单了',
        f'{g.user["username"]} 接取了你的任务「{task["title"]}」',
        f'/task/{task_id}'
    )
    
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': '接单成功！请在截止日期前完成交付。'})


@app.route('/task/<int:task_id>/deliver', methods=['POST'])
def deliver_task(task_id):
    """交付功能 - 必须提交产出物链接"""
    if not g.user:
        return jsonify({'error': '请先登录'}), 401
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT * FROM tasks WHERE id = ? AND worker_id = ? AND status = "in_progress"
    ''', (task_id, g.user['id']))
    task = cursor.fetchone()
    
    if not task:
        conn.close()
        return jsonify({'error': '任务不存在或你不是接单人'}), 400
    
    task = dict(task)
    delivery_url = request.form.get('delivery_url', '').strip()
    delivery_note = request.form.get('delivery_note', '').strip()
    
    if not delivery_url:
        conn.close()
        return jsonify({'error': '必须提交交付链接'}), 400
    
    cursor.execute('''
        UPDATE tasks SET status = "pending_review", delivery_url = ?, delivery_note = ?,
        delivery_time = ? WHERE id = ?
    ''', (delivery_url, delivery_note, datetime.now().isoformat(), task_id))
    
    create_notification(
        task['publisher_id'],
        'task_deliver',
        '任务已交付',
        f'{g.user["username"]} 已完成任务「{task["title"]}」，请审核',
        f'/task/{task_id}'
    )
    
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': '交付成功！等待发布者审核。'})


@app.route('/task/<int:task_id>/approve', methods=['POST'])
def approve_task(task_id):
    """审核通过"""
    if not g.user:
        return jsonify({'error': '请先登录'}), 401
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT t.* FROM tasks t WHERE t.id = ? AND t.publisher_id = ? AND t.status = "pending_review"
    ''', (task_id, g.user['id']))
    task = cursor.fetchone()
    
    if not task:
        conn.close()
        return jsonify({'error': '任务不存在或你不是发布者'}), 400
    
    task = dict(task)
    
    cursor.execute('''
        UPDATE tasks SET status = "completed", review_time = ? WHERE id = ?
    ''', (datetime.now().isoformat(), task_id))
    
    # 记录基础积分
    cursor.execute('UPDATE tasks SET base_points = ? WHERE id = ?', (task['bounty'], task_id))
    
    create_notification(
        task['worker_id'],
        'task_approve',
        '任务审核通过',
        f'你的任务「{task["title"]}」已通过审核，请进行评价',
        f'/task/{task_id}'
    )
    
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': '审核通过！请进行评价。'})


@app.route('/task/<int:task_id>/reject', methods=['POST'])
def reject_task(task_id):
    """审核驳回"""
    if not g.user:
        return jsonify({'error': '请先登录'}), 401
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT t.* FROM tasks t WHERE t.id = ? AND t.publisher_id = ? AND t.status = "pending_review"
    ''', (task_id, g.user['id']))
    task = cursor.fetchone()
    
    if not task:
        conn.close()
        return jsonify({'error': '任务不存在或你不是发布者'}), 400
    
    task = dict(task)
    reason = request.form.get('reason', '质量不符合要求')
    
    cursor.execute('''
        UPDATE tasks SET status = "in_progress", reject_reason = ?,
        delivery_url = NULL, delivery_note = NULL, delivery_time = NULL
        WHERE id = ?
    ''', (reason, task_id))
    
    create_notification(
        task['worker_id'],
        'task_reject',
        '任务被驳回',
        f'你的任务「{task["title"]}」被驳回：{reason}',
        f'/task/{task_id}'
    )
    
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': f'已驳回：{reason}'})


@app.route('/task/<int:task_id>/review', methods=['POST'])
def review_task(task_id):
    """多维度评价"""
    if not g.user:
        return jsonify({'error': '请先登录'}), 401
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM tasks WHERE id = ? AND status = "completed"', (task_id,))
    task = cursor.fetchone()
    
    if not task:
        conn.close()
        return jsonify({'error': '任务不存在或未完成'}), 400
    
    task = dict(task)
    
    if g.user['id'] == task['publisher_id']:
        reviewee_id = task['worker_id']
    elif g.user['id'] == task['worker_id']:
        reviewee_id = task['publisher_id']
    else:
        conn.close()
        return jsonify({'error': '你不是任务相关方'}), 403
    
    cursor.execute('SELECT * FROM reviews WHERE task_id = ? AND reviewer_id = ?',
                  (task_id, g.user['id']))
    if cursor.fetchone():
        conn.close()
        return jsonify({'error': '你已经评价过了'}), 400
    
    rating = int(request.form.get('rating', 5))
    comment = request.form.get('comment', '')
    completion_score = int(request.form.get('completion_score', 100))
    punctuality_score = int(request.form.get('punctuality_score', 100))
    communication_score = int(request.form.get('communication_score', 100))
    
    cursor.execute('''
        INSERT INTO reviews (task_id, reviewer_id, reviewee_id, rating, comment,
                          completion_score, punctuality_score, communication_score)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (task_id, g.user['id'], reviewee_id, rating, comment,
          completion_score, punctuality_score, communication_score))
    
    # 检查是否双方都评价了
    cursor.execute('SELECT COUNT(*) FROM reviews WHERE task_id = ?', (task_id,))
    review_count = cursor.fetchone()[0]
    
    settlement_message = ""
    if review_count >= 2:
        settlement_message = settle_task_points(conn, cursor, task_id, task)
    
    # 更新被评价人的信任评分
    calculate_trust_score(reviewee_id)
    
    create_notification(
        reviewee_id,
        'review_received',
        '收到新评价',
        f'{g.user["username"]} 给了你 {rating} 星评价',
        f'/task/{task_id}'
    )
    
    conn.commit()
    conn.close()
    
    return jsonify({
        'success': True,
        'message': f"评价成功！{settlement_message if settlement_message else ' 等待对方评价。'}"
    })


def settle_task_points(conn, cursor, task_id, task):
    """v6积分结算"""
    cursor.execute('SELECT * FROM reviews WHERE task_id = ?', (task_id,))
    reviews = [dict(row) for row in cursor.fetchall()]
    
    if len(reviews) < 2:
        return ""
    
    avg_rating = sum(r['rating'] for r in reviews) / len(reviews)
    
    # 获取被评价人的信息
    cursor.execute('SELECT * FROM users WHERE id = ?', (task['worker_id'],))
    worker = dict(cursor.fetchone())
    
    final_points = calculate_points_formula(
        task['bounty'],
        avg_rating,
        worker['trust_score'],
        worker.get('quality_score', 100.0),
        worker.get('dispute_count', 0)
    )
    
    quality_bonus = final_points - task['bounty']
    
    cursor.execute('''UPDATE tasks SET final_points = ?, final_score = ?, quality_bonus = ? 
                     WHERE id = ?''', (final_points, avg_rating, quality_bonus, task_id))
    
    cursor.execute('''UPDATE users SET points = points + ?, total_tasks = total_tasks + 1, 
                     total_earnings = total_earnings + ? WHERE id = ?''',
                  (final_points, final_points, task['worker_id']))
    
    cursor.execute('''
        INSERT INTO transactions (user_id, amount, type, task_id, description, source_type)
        VALUES (?, ?, 'earn', ?, ?, '任务完成')
    ''', (task['worker_id'], final_points, task_id, f'任务「{task["title"]}」完成'))
    
    # 记录协作历史
    cursor.execute('''
        INSERT INTO collaboration_history (task_id, user_id, partner_id, role, outcome, rating, points_earned)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (task_id, task['publisher_id'], task['worker_id'], 'publisher', 'completed', int(avg_rating), final_points))
    
    cursor.execute('''
        INSERT INTO collaboration_history (task_id, user_id, partner_id, role, outcome, rating, points_earned)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (task_id, task['worker_id'], task['publisher_id'], 'worker', 'completed', int(avg_rating), final_points))
    
    return f"积分已结算：{final_points}分"


# ========== 协商沟通 ==========
@app.route('/task/<int:task_id>/negotiate', methods=['POST'])
def task_negotiate(task_id):
    """发送协商消息"""
    if not g.user:
        return jsonify({'error': '请先登录'}), 401
    
    message = request.form.get('message', '').strip()
    if not message:
        return jsonify({'error': '消息不能为空'}), 400
    
    conn = get_db()
    cursor = conn.cursor()
    
    # 检查用户是否是任务相关方
    cursor.execute('SELECT * FROM tasks WHERE id = ? AND (publisher_id = ? OR worker_id = ?)',
                  (task_id, g.user['id'], g.user['id']))
    if not cursor.fetchone():
        conn.close()
        return jsonify({'error': '你不是任务相关方'}), 400
    
    cursor.execute('''
        INSERT INTO task_negotiations (task_id, user_id, message)
        VALUES (?, ?, ?)
    ''', (task_id, g.user['id'], message))
    
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': '消息已发送'})


# ========== 争议处理 ==========
@app.route('/task/<int:task_id>/dispute', methods=['POST'])
def create_dispute(task_id):
    """创建争议"""
    if not g.user:
        return jsonify({'error': '请先登录'}), 401
    
    reason = request.form.get('reason', '').strip()
    if not reason:
        return jsonify({'error': '请填写争议原因'}), 400
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM tasks WHERE id = ?', (task_id,))
    task = dict(cursor.fetchone())
    
    if not task:
        conn.close()
        return jsonify({'error': '任务不存在'}), 400
    
    # 确定争议双方
    if g.user['id'] == task['publisher_id']:
        against_id = task['worker_id']
    elif g.user['id'] == task['worker_id']:
        against_id = task['publisher_id']
    else:
        conn.close()
        return jsonify({'error': '你不是任务相关方'}), 400
    
    if not against_id:
        conn.close()
        return jsonify({'error': '任务尚未有人接单'}), 400
    
    # 检查是否已有争议
    cursor.execute('SELECT id FROM disputes WHERE task_id = ? AND status = "open"', (task_id,))
    if cursor.fetchone():
        conn.close()
        return jsonify({'error': '该任务已有待处理争议'}), 400
    
    evidence = request.form.get('evidence', '')
    
    cursor.execute('''
        INSERT INTO disputes (task_id, raised_by, against, reason, evidence)
        VALUES (?, ?, ?, ?, ?)
    ''', (task_id, g.user['id'], against_id, reason, evidence))
    
    # 更新用户争议计数
    cursor.execute('UPDATE users SET dispute_count = dispute_count + 1 WHERE id = ?', (against_id,))
    
    # 获取仲裁员
    cursor.execute('''
        SELECT a.*, u.username FROM arbitrators a
        LEFT JOIN users u ON a.user_id = u.id
        WHERE a.is_active = 1
        ORDER BY a.rating DESC, a.cases_handled ASC
        LIMIT 1
    ''')
    arbitrator = cursor.fetchone()
    
    if arbitrator:
        arbitrator_id = arbitrator['user_id']
        cursor.execute('UPDATE disputes SET arbitrator_id = ? WHERE task_id = ?', (arbitrator_id, task_id))
        create_notification(
            arbitrator_id,
            'new_dispute',
            '新争议案件',
            f'任务「{task["title"]}」产生争议，需要仲裁',
            f'/disputes'
        )
    
    create_notification(
        against_id,
        'dispute_raised',
        '收到争议投诉',
        f'你的任务「{task["title"]}」被提起争议',
        f'/task/{task_id}'
    )
    
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': '争议已提交，等待仲裁处理'})


@app.route('/disputes')
def disputes_list():
    """争议列表"""
    if not g.user:
        flash('请先登录', 'warning')
        return redirect(url_for('login'))
    
    conn = get_db()
    cursor = conn.cursor()
    
    # 检查是否是仲裁员
    cursor.execute('SELECT * FROM arbitrators WHERE user_id = ?', (g.user['id'],))
    is_arbitrator = cursor.fetchone() is not None
    
    if is_arbitrator:
        cursor.execute('''
            SELECT d.*, t.title as task_title, 
                   r.username as raiser_name, a.username as against_name
            FROM disputes d
            LEFT JOIN tasks t ON d.task_id = t.id
            LEFT JOIN users r ON d.raised_by = r.id
            LEFT JOIN users a ON d.against = a.id
            ORDER BY d.status ASC, d.created_at DESC
        ''')
    else:
        cursor.execute('''
            SELECT d.*, t.title as task_title, 
                   r.username as raiser_name, a.username as against_name
            FROM disputes d
            LEFT JOIN tasks t ON d.task_id = t.id
            LEFT JOIN users r ON d.raised_by = r.id
            LEFT JOIN users a ON d.against = a.id
            WHERE d.raised_by = ? OR d.against = ?
            ORDER BY d.status ASC, d.created_at DESC
        ''', (g.user['id'], g.user['id']))
    
    disputes = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return render_template('disputes.html', disputes=disputes, is_arbitrator=is_arbitrator)


# ========== 我的任务 ==========
@app.route('/my_tasks')
def my_tasks():
    if not g.user:
        flash('请先登录', 'warning')
        return redirect(url_for('login'))
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT t.*, w.username as worker_name
        FROM tasks t
        LEFT JOIN users w ON t.worker_id = w.id
        WHERE t.publisher_id = ?
        ORDER BY t.created_at DESC
    ''', (g.user['id'],))
    published = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute('''
        SELECT t.*, p.username as publisher_name, p.trust_score as publisher_score
        FROM tasks t
        LEFT JOIN users p ON t.publisher_id = p.id
        WHERE t.worker_id = ?
        ORDER BY t.created_at DESC
    ''', (g.user['id'],))
    accepted = [dict(row) for row in cursor.fetchall()]
    
    # 协作历史
    cursor.execute('''
        SELECT t.*, p.username as publisher_name, w.username as worker_name
        FROM tasks t
        LEFT JOIN users p ON t.publisher_id = p.id
        LEFT JOIN users w ON t.worker_id = w.id
        WHERE (t.publisher_id = ? OR t.worker_id = ?) AND t.status = 'completed'
        ORDER BY t.review_time DESC
    ''', (g.user['id'], g.user['id']))
    history = [dict(row) for row in cursor.fetchall()]
    
    worker_scores = get_task_worker_scores(published)
    
    # 统计
    in_progress_count = sum(1 for t in published + accepted if t['status'] == 'in_progress')
    completed_count = sum(1 for t in published + accepted if t['status'] == 'completed')
    
    conn.close()
    
    return render_template('tasks/my_tasks.html', 
                         published=published, 
                         accepted=accepted,
                         history=history,
                         worker_scores=worker_scores,
                         in_progress_count=in_progress_count,
                         completed_count=completed_count)


# ========== 个人主页 ==========
@app.route('/user/<int:user_id>')
def user_profile(user_id):
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM users WHERE id = ? AND is_active = 1', (user_id,))
    profile_user = cursor.fetchone()
    
    if not profile_user:
        conn.close()
        flash('用户不存在', 'error')
        return redirect(url_for('index'))
    
    profile_user = dict(profile_user)
    
    user_stats = get_user_stats(user_id)
    
    cursor.execute('''
        SELECT t.*, p.username as publisher_name
        FROM tasks t
        LEFT JOIN users p ON t.publisher_id = p.id
        WHERE (t.publisher_id = ? OR t.worker_id = ?) AND t.status = 'completed'
        ORDER BY t.review_time DESC
        LIMIT 10
    ''', (user_id, user_id))
    user_tasks = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute('''
        SELECT r.*, t.title as task_title, u.username as reviewer_name
        FROM reviews r
        LEFT JOIN tasks t ON r.task_id = t.id
        LEFT JOIN users u ON r.reviewer_id = u.id
        WHERE r.reviewee_id = ?
        ORDER BY r.created_at DESC
        LIMIT 5
    ''', (user_id,))
    user_reviews = [dict(row) for row in cursor.fetchall()]
    
    conn.close()
    
    return render_template('user/profile.html',
                         profile_user=profile_user,
                         user_stats=user_stats,
                         user_tasks=user_tasks,
                         user_reviews=user_reviews)


@app.route('/user/<int:user_id>/tags', methods=['POST'])
def update_skill_tags(user_id):
    """更新能力标签"""
    if not g.user or g.user['id'] != user_id:
        return jsonify({'error': '无权限'}), 403
    
    tags = request.form.get('tags', '').strip()
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET skill_tags = ? WHERE id = ?', (tags, user_id))
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': '标签已更新'})


# ========== 积分追溯 ==========
@app.route('/transactions')
def transactions():
    """积分交易记录"""
    if not g.user:
        flash('请先登录', 'warning')
        return redirect(url_for('login'))
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT tr.*, t.title as task_title
        FROM transactions tr
        LEFT JOIN tasks t ON tr.task_id = t.id
        WHERE tr.user_id = ?
        ORDER BY tr.created_at DESC
        LIMIT 50
    ''', (g.user['id'],))
    transactions_list = [dict(row) for row in cursor.fetchall()]
    
    conn.close()
    
    return render_template('transactions.html', transactions=transactions_list)


# ========== 论坛 ==========
@app.route('/forum')
def forum():
    conn = get_db()
    cursor = conn.cursor()
    
    category = request.args.get('category', '')
    sort = request.args.get('sort', 'latest')
    
    query = '''
        SELECT fp.*, u.username as author_name, u.trust_score as author_score,
               pq.price, pq.is_unlocked
        FROM forum_posts fp
        LEFT JOIN users u ON fp.author_id = u.id
        LEFT JOIN paid_questions pq ON fp.id = pq.post_id
        WHERE 1=1
    '''
    params = []
    
    if category:
        query += ' AND fp.category = ?'
        params.append(category)
    
    if sort == 'latest':
        query += ' ORDER BY fp.is_pinned DESC, fp.last_reply_at DESC'
    elif sort == 'hot':
        query += ' ORDER BY fp.is_pinned DESC, fp.view_count DESC'
    else:
        query += ' ORDER BY fp.is_pinned DESC, fp.created_at DESC'
    
    cursor.execute(query, params)
    posts = [dict(row) for row in cursor.fetchall()]
    
    conn.close()
    
    return render_template('forum/forum.html', posts=posts, 
                         current_category=category, sort=sort)


@app.route('/forum/post/<int:post_id>')
def forum_post(post_id):
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT fp.*, u.username as author_name, u.trust_score as author_score, u.bio as author_bio
        FROM forum_posts fp
        LEFT JOIN users u ON fp.author_id = u.id
        WHERE fp.id = ?
    ''', (post_id,))
    post = dict(cursor.fetchone())
    
    cursor.execute('UPDATE forum_posts SET view_count = view_count + 1 WHERE id = ?', (post_id,))
    
    is_unlocked = True
    if post.get('price') and post['price'] > 0:
        if g.user:
            cursor.execute('''
                SELECT * FROM paid_questions WHERE post_id = ? AND unlocker_id = ?
            ''', (post_id, g.user['id']))
            is_unlocked = cursor.fetchone() is not None
        else:
            is_unlocked = False
    
    cursor.execute('''
        SELECT fr.*, u.username as author_name, u.trust_score as author_score
        FROM forum_replies fr
        LEFT JOIN users u ON fr.author_id = u.id
        WHERE fr.post_id = ?
        ORDER BY fr.is_best DESC, fr.created_at ASC
    ''', (post_id,))
    replies = [dict(row) for row in cursor.fetchall()]
    
    conn.commit()
    conn.close()
    
    return render_template('forum/post.html', post=post, replies=replies, is_unlocked=is_unlocked)


@app.route('/forum/create', methods=['GET', 'POST'])
def forum_create():
    if not g.user:
        flash('请先登录', 'warning')
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        content = request.form.get('content', '').strip()
        category = request.form.get('category', 'general')
        is_paid = request.form.get('is_paid')
        price = int(request.form.get('price', 10)) if is_paid else 0
        
        if not title or not content:
            flash('请填写标题和内容', 'error')
            return render_template('forum/create.html')
        
        if price > 0 and g.user['points'] < price:
            flash('积分不足', 'error')
            return render_template('forum/create.html')
        
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO forum_posts (title, content, category, author_id)
            VALUES (?, ?, ?, ?)
        ''', (title, content, category, g.user['id']))
        post_id = cursor.lastrowid
        
        if price > 0:
            cursor.execute('''
                INSERT INTO paid_questions (post_id, price)
                VALUES (?, ?)
            ''', (post_id, price))
            cursor.execute('UPDATE users SET points = points - ? WHERE id = ?', (price, g.user['id']))
        
        conn.commit()
        conn.close()
        
        flash('帖子发布成功！', 'success')
        return redirect(url_for('forum_post', post_id=post_id))
    
    return render_template('forum/create.html')


@app.route('/forum/post/<int:post_id>/reply', methods=['POST'])
def forum_reply(post_id):
    if not g.user:
        return jsonify({'error': '请先登录'}), 401
    
    content = request.form.get('content', '').strip()
    if not content:
        return jsonify({'error': '回复内容不能为空'}), 400
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM forum_posts WHERE id = ? AND is_locked = 0', (post_id,))
    if not cursor.fetchone():
        conn.close()
        return jsonify({'error': '帖子不存在或已锁定'}), 400
    
    cursor.execute('''
        INSERT INTO forum_replies (post_id, author_id, content)
        VALUES (?, ?, ?)
    ''', (post_id, g.user['id'], content))
    
    cursor.execute('''
        UPDATE forum_posts SET reply_count = reply_count + 1, last_reply_at = ?
        WHERE id = ?
    ''', (datetime.now().isoformat(), post_id))
    
    cursor.execute('SELECT author_id, title FROM forum_posts WHERE id = ?', (post_id,))
    post = cursor.fetchone()
    
    if post['author_id'] != g.user['id']:
        create_notification(
            post['author_id'],
            'forum_reply',
            '收到回复',
            f'{g.user["username"]} 回复了你的帖子「{post["title"]}」',
            f'/forum/post/{post_id}'
        )
    
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': '回复成功！'})


@app.route('/forum/reply/<int:reply_id>/like', methods=['POST'])
def like_reply(reply_id):
    if not g.user:
        return jsonify({'error': '请先登录'}), 401
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT * FROM likes WHERE user_id = ? AND target_type = 'reply' AND target_id = ?
    ''', (g.user['id'], reply_id))
    
    if cursor.fetchone():
        cursor.execute('''
            DELETE FROM likes WHERE user_id = ? AND target_type = 'reply' AND target_id = ?
        ''', (g.user['id'], reply_id))
        cursor.execute('UPDATE forum_replies SET like_count = like_count - 1 WHERE id = ?', (reply_id,))
        liked = False
    else:
        cursor.execute('''
            INSERT INTO likes (user_id, target_type, target_id)
            VALUES (?, 'reply', ?)
        ''', (g.user['id'], reply_id))
        cursor.execute('UPDATE forum_replies SET like_count = like_count + 1 WHERE id = ?', (reply_id,))
        liked = True
    
    cursor.execute('SELECT like_count FROM forum_replies WHERE id = ?', (reply_id,))
    like_count = cursor.fetchone()[0]
    
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'liked': liked, 'like_count': like_count})


# ========== 通知 ==========
@app.route('/notifications')
def notifications():
    if not g.user:
        flash('请先登录', 'warning')
        return redirect(url_for('login'))
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT * FROM notifications WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 50
    ''', (g.user['id'],))
    notifications_list = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute('UPDATE notifications SET is_read = 1 WHERE user_id = ?', (g.user['id'],))
    
    conn.commit()
    conn.close()
    
    return render_template('notifications.html', notifications=notifications_list)


@app.route('/api/notifications/count')
def api_notifications_count():
    if not g.user:
        return jsonify({'count': 0})
    return jsonify({'count': g.unread_count})


# ========== 数据看板 ==========
@app.route('/dashboard')
def dashboard():
    if not g.user:
        flash('请先登录', 'warning')
        return redirect(url_for('login'))
    
    conn = get_db()
    cursor = conn.cursor()
    
    stats = get_user_stats(g.user['id'])
    
    cursor.execute('''
        SELECT * FROM transactions WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 10
    ''', (g.user['id'],))
    transactions = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute('''
        SELECT r.*, t.title as task_title, u.username as reviewer_name
        FROM reviews r
        LEFT JOIN tasks t ON r.task_id = t.id
        LEFT JOIN users u ON r.reviewer_id = u.id
        WHERE r.reviewee_id = ?
        ORDER BY r.created_at DESC
        LIMIT 5
    ''', (g.user['id'],))
    recent_reviews = [dict(row) for row in cursor.fetchall()]
    
    platform_stats = get_platform_stats()
    
    conn.close()
    
    return render_template('dashboard.html', 
                         stats=stats,
                         transactions=transactions,
                         recent_reviews=recent_reviews,
                         platform_stats=platform_stats)


# ========== API ==========
@app.route('/api/user')
def api_user():
    if not g.user:
        return jsonify({'error': '未登录'}), 401
    return jsonify(g.user)


@app.route('/api/templates')
def api_templates():
    """获取任务模板"""
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM task_templates ORDER BY usage_count DESC')
    templates = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify(templates)


@app.route('/template/<int:template_id>/use', methods=['POST'])
def use_template(template_id):
    """使用模板"""
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE task_templates SET usage_count = usage_count + 1 WHERE id = ?', (template_id,))
    cursor.execute('SELECT * FROM task_templates WHERE id = ?', (template_id,))
    template = cursor.fetchone()
    conn.commit()
    conn.close()
    
    if template:
        return jsonify({'success': True, 'template': dict(template)})
    return jsonify({'error': '模板不存在'}), 404


# ========== 启动 ==========
if __name__ == '__main__':
    print("🚀 Agent协作平台 v6 启动中...")
    print("📍 访问地址: http://127.0.0.1:5000")
    print("📝 默认用户: publisher_demo / demo123")
    print("✨ 新功能: 协商沟通 | 争议处理 | 仲裁系统 | 多维度评价 | 积分追溯")
    app.run(debug=True, port=5000)
